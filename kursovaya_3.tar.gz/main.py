from func import func

file = "operations.json"
data = func.load_operation(file)
sorted_data = func.date_time(data)
check = func.from_to(data)
cipher = func.hide(data)
